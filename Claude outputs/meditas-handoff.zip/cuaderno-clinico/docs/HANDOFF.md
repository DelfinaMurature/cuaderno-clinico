# Handoff — Meditas (Cuaderno Clínico)

Resumen para retomar este proyecto en otra conversación con Claude, partiendo exactamente de donde quedó.

## Qué es

"Meditas" (antes "Cuaderno clínico"): PWA de estudio y residencia médica para la hermana de Max, residente de neurocirugía. Vite 8 + vite-plugin-pwa, JS vanilla, IndexedDB, sincronización con Supabase, deploy en GitHub Pages.

## Dónde vive el código

- Carpeta en la máquina de Max: `C:\Users\maxim\Documents\cuaderno-clinico` (Windows), conectada por el puente de dispositivo de Cowork.
- Repo en GitHub (Max pushea él mismo, no Claude).
- Esta sesión trabajó en una copia cloud en `/home/claude/cuaderno-clinico` y entregó los cambios a la carpeta de Max vía `.tgz` + `device_commit_files`, extraído con `tar --overwrite --no-same-owner`.

## Estado actual (última entrega: commit ya pusheado por Max)

Se aplicó un pedido de correcciones de la hermana de Max, recibido en un Google Doc (ID `1tfef1ZJWivZP7_egaMuDoWV0G6RjzexUbm_RjRqi2_M`). Todo lo del documento está implementado y pusheado:

1. **Navegación de 9 accesos** (sin menú «Más»), en este orden: Hoy, Patologías, Procedimientos, Evolución, Partes Quirúrgicos, Fórmulas y Scores, Estadísticas, Repaso, Configuración. Responsive: barra inferior desplazable en celular, barra lateral en pantalla ancha. Rutas viejas (`#/mas/...`) siguen funcionando.
2. **Patologías**: cada ficha permite agregar/quitar recuadros (incluidos recuadros propios con título libre) y todos los recuadros tienen una barra de formato tipo Google Docs (negrita, cursiva, subrayado, listas, fuente, tamaño, color). Implementado en `src/rich.js` (sanitizador + motor de formato) e integrado en `src/app.js` y `src/data.js` (`fieldsOf`). Las fichas viejas en texto plano se siguen leyendo igual.
   - **Hubo un bug corregido después de la primera entrega**: el HTML enriquecido sin la marca `<!--rt-->` a veces se confundía con texto plano y mostraba las etiquetas crudas (`<div>`, `&gt;`). Se arregló agregando la constante `RT` y la función `pack()` en `src/rich.js`, y detectando HTML también por patrones de cierre de etiqueta. Ya entregado y pusheado.
3. **Evolución**: navegación reestructurada por categorías (como Partes), con buscador. Motor en `src/evo/engine.js`, UI en `src/evo/ui.js`.
4. **Repaso**: modos patologías/procedimientos/mixto verificados, funcionan con fichas de texto enriquecido (usan `plain()` de `rich.js` para extraer texto llano).
5. **Fórmulas y Scores**: módulo nuevo completo en `src/calc/` (motor `engine.js`, catálogo `lib/index.js` + 6 archivos de datos, UI `ui.js`). 256 herramientas (124 fórmulas + 132 scores), buscador global, favoritos, categorías por especialidad, pantalla de herramienta con fórmula/fuente/versión/límites, nunca calcula con datos faltantes. 616/616 tests pasan (`scripts/validar-calc.mjs`). Las fórmulas propias del usuario viejas (`src/formulas.js`, ahora "Mis fórmulas") se conservan aparte, no se mezclan con el catálogo.
   - Herramientas marcadas `pend` (pendiente de verificación, no calculan): transf-incremento-hb, correccion-electrolitos-ped, PRECISE-DAPT, alertas de sepsis, MEOWS, PRISM III, BVAS, FRAX.
   - **Pendiente de avisar a Max**: los puntajes de Glasgow, NIHSS, HEART y APACHE en el catálogo los completaron subagentes desde memoria, no verificados contra la fuente original en esta sesión. Algunas bandas de interpretación (Morse, GRACE, Westley) tampoco son textuales del paper original. Conviene que su hermana los revise antes de confiar en ellos clínicamente.
6. **Partes quirúrgicos v2**: flujo especialidad → categoría → buscador → variante → modo rápido/detallado → formulario → vista editable. Motor extendido en `src/partes/engine.js` (variantes `vr`, modo `q`, condicionales `if`/`ifn`, pasos condicionados, alias con `set`). 121 plantillas: 58 Cirugía General + 63 Neurocirugía, repartidas en `src/partes/lib/{cg-abdominal,cg-pared,cg-otros,nc-craneal,nc-columna,nc-lcr-vascular}.js`. Traumatología se sacó del catálogo (archivo viejo movido a `_to_delete/` en la carpeta de Max, no borrado por las reglas del puente de dispositivo). Duplicar un borrador ya no copia datos clínicos. 616 tests de cálculo + validación de 121 plantillas en ambos modos (rápido/detallado) vía Playwright, sin errores.

## Validadores y tests

- `node scripts/validar-calc.mjs` — valida catálogo de Fórmulas y Scores + corre casos de prueba.
- `node scripts/validar-plantillas.mjs src/evo/lib/*.js src/partes/lib/*.js` (sin `index.js`) — valida esquema de plantillas de evolución y partes.
- Pruebas de extremo a extremo con Playwright (Chromium en `/opt/pw-browsers/chromium`, `vite preview` en puerto 4175) corridas contra todas las plantillas de partes (121, ambos modos) y evolución (27), sin textos rotos ni errores de consola.
- No se probó: sincronización real con Supabase, modo oscuro de esta versión específica.

## Esquemas de referencia

- `docs/ESQUEMA_PLANTILLAS.md` — esquema de plantillas de evolución (v1) y partes (v2: variantes, modo, condicionales).
- `docs/ESQUEMA_CALCULADORAS.md` — esquema del catálogo de Fórmulas y Scores.

## Convenciones del proyecto (para quien retome)

- Motores de plantillas son data-driven: los archivos de `lib/` son datos puros (sin funciones salvo `calc` en calculadoras), el motor (`engine.js`) renderiza texto.
- Router por hash (`#/seccion/...`), sin librería de routing.
- Estado único `S`, persistido en IndexedDB (`store.js`) y sincronizado con Supabase (`sync.js`) salvo campos `LOCAL_ONLY` (datos de pacientes: evoluciones, partes, etc. — nunca salen del dispositivo).
- Diseño con tokens CSS, dos skins (`clinico`, `cuaderno`) × claro/oscuro, sin `color-mix()`.
- Build target `es2019`/`safari14`.

## Cómo seguir

Para cualquier cambio nuevo, lo más simple es pedirle a Claude que lea este archivo (`docs/HANDOFF.md`) al empezar, y luego trabajar como siempre: editar en la copia cloud o directo en la carpeta de Max vía el puente de dispositivo, validar con los scripts de arriba, probar con Playwright si el cambio es grande, entregar y pedirle a Max que compile y pushee él mismo (`npm run build && git add -A && git commit && git push`).
